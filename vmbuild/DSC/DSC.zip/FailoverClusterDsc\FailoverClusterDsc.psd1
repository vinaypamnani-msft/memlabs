@{
    moduleVersion        = '2.2.0'

    GUID                 = '026e7fd8-06dd-41bc-b373-59366ab18679'

    Author               = 'DSC Community'

    CompanyName          = 'DSC Community'

    Copyright            = 'Copyright the DSC Community contributors. All rights reserved.'

    Description          = 'Module containing DSC resources for deployment and configuration of Windows Server Failover Cluster.'

    # Minimum version of the Windows PowerShell engine required by this module
    PowerShellVersion    = '4.0'

    # Functions to export from this module
    FunctionsToExport    = @()

    # Cmdlets to export from this module
    CmdletsToExport      = @()

    # Variables to export from this module
    VariablesToExport    = @()

    # Aliases to export from this module
    AliasesToExport      = @()

    DscResourcesToExport = @('Cluster','ClusterDisk','ClusterIPAddress','ClusterNetwork','ClusterPreferredOwner','ClusterProperty','ClusterQuorum','WaitForCluster')

    # Private data to pass to the module specified in RootModule/ModuleToProcess. This may also contain a PSData hashtable with additional module metadata used by PowerShell.
    PrivateData          = @{
        PSData = @{
            # Set to a prerelease string value if the release should be a prerelease.
            Prerelease   = ''

            # Tags applied to this module. These help with module discovery in online galleries.
            Tags         = @('DesiredStateConfiguration', 'DSC', 'DSCResourceKit', 'DSCResource')

            # A URL to the license for this module.
            LicenseUri   = 'https://github.com/dsccommunity/FailOverClusterDsc/blob/main/LICENSE'

            # A URL to the main website for this project.
            ProjectUri   = 'https://github.com/dsccommunity/FailOverClusterDsc'

            # A URL to an icon representing this module.
            IconUri      = 'https://dsccommunity.org/images/DSC_Logo_300p.png'

            # ReleaseNotes of this module
            ReleaseNotes = '## [2.2.0] - 2025-05-22

### Fixed

- Cluster
  - Fixed Get-TargetResource is reporting error when cluster is not found ([issue #283](https://github.com/dsccommunity/FailOverClusterDsc/issues/283)).

### Changed

- FailoverClusterDsc
  - URLs in module manifest now points to the renamed repository.
  - Fixed build pipeline to use GitVersion v5.
  - Switch build pipeline to use `windows-latest` as the build agent.
  - Update latest module files from Sampler.
  - Use matrix pipeline strategy.
  - Try using CodeCov CLI
  - Update CodeCov CLI command
  - Use CodeCov upload-process

'
        } # End of PSData hashtable

    } # End of PrivateData hashtable
}
