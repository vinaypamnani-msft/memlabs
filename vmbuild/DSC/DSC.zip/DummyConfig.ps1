﻿Configuration DummyConfig {

    # Cheat to include all modules guest VM's would need, so we have an exported copy.
    Import-DscResource -ModuleName @{ ModuleName = 'PSDesiredStateConfiguration'; ModuleVersion = '1.1' }, @{ ModuleName = 'ActiveDirectoryDsc'; ModuleVersion = '6.7.1' }, @{ ModuleName = 'xDscDiagnostics'; ModuleVersion = '2.8.0' }, @{ ModuleName = 'ComputerManagementDsc'; ModuleVersion = '10.0.0' }, @{ ModuleName = 'DnsServerDsc'; ModuleVersion = '3.0.3' }, @{ ModuleName = 'SqlServerDsc'; ModuleVersion = '17.5.1' }, @{ ModuleName = 'xDhcpServer'; ModuleVersion = '3.1.2' }, @{ ModuleName = 'NetworkingDsc'; ModuleVersion = '9.1.0' }, @{ ModuleName = 'FailoverClusterDsc'; ModuleVersion = '2.2.0' }, @{ ModuleName = 'AccessControlDsc'; ModuleVersion = '1.4.3' }, @{ ModuleName = 'UpdateServicesDsc'; ModuleVersion = '1.3.0' }, @{ ModuleName = 'LanguageDsc'; ModuleVersion = '1.0.0.0' }, @{ ModuleName = 'GroupPolicyDsc'; ModuleVersion = '1.0.3' }, @{ ModuleName = 'CertificateDsc'; ModuleVersion = '6.0.0' }

    Node LOCALHOST {

        LocalConfigurationManager {
            ConfigurationMode  = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        Script Initialize_Disk
        {
            DependsOn = '[xIPAddress]NewIPAddress'
            SetScript = {
                # Start logging the actions
                Start-Transcript -Path $env:windir\temp\Diskinitlog.txt -Append -Force

                # Move CD-ROM drive to Z:
                "Moving CD-ROM drive to Z:.."
                Get-WmiObject -Class Win32_volume -Filter 'DriveType=5' | Select-Object -First 1 | Set-WmiInstance -Arguments @{DriveLetter='Z:'}

                # Set the parameters
                $disks = Get-Disk | Where-Object partitionstyle -eq 'raw' | Sort-Object number
                $letters = 69..89 | ForEach-Object { [char]$_ }
                $count = 0
                $label = "Data"

                "Formatting disks.."
                foreach ($disk in $disks) {
                    $driveLetter = $letters[$count].ToString()
                    $disk | Initialize-Disk -PartitionStyle MBR -PassThru | New-Partition -UseMaximumSize -DriveLetter $driveLetter | Format-Volume -FileSystem NTFS -NewFileSystemLabel "$label.$count" -Confirm:$false -Force
                    "$label.$count"
                    $count++
                }

                Stop-Transcript
            }

            TestScript = {
                try
                {
                    Write-Verbose "Testing if any Raw disks are left"

                    # $Validate = New-Object -ComObject 'AgentConfigManager.MgmtSvcCfg' -ErrorAction SilentlyContinue
                    $Validate = Get-Disk | Where-Object partitionstyle -eq 'raw'
                }
                catch
                {
                    $ErrorMessage = $_.Exception.Message
                    $ErrorMessage
                }

                If (!($Validate -eq $null))
                {
                    Write-Verbose "Disks are not initialized"
                    return $False
                }
                Else
                {
                    Write-Verbose "Disks are initialized"
                    Return $True
                }
            }

            GetScript = { @{ Result = Get-Disk | Where-Object partitionstyle -eq 'raw' } }
        }


    }
}