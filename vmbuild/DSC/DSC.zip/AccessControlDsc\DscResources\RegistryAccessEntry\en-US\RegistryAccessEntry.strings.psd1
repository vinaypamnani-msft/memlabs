ConvertFrom-StringData -StringData @'   

'@
