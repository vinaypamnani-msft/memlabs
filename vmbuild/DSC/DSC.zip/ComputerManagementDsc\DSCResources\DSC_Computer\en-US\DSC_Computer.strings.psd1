ConvertFrom-StringData @'
    GettingComputerStateMessage = Getting computer state for '{0}'.
    SettingComputerStateMessage = Setting computer state for '{0}'.
    SettingComputerDescriptionMessage = Setting computer description to '{0}'.
    RenamedComputerMessage = Renamed computer to '{0}'.
    RenamedComputerAndJoinedDomainMessage = Renamed computer to '{0}' and added to the domain '{1}'.
    JoinedDomainMessage = Added computer to domain '{0}'.
    FailToRenameAfterJoinDomainMessage = Failed to rename the computer during the domain join. Re-trying the rename.
    RenamedComputerAndJoinedWorkgroupMessage = Renamed computer to '{0}' and addded to workgroup '{1}'.
    JoinedWorkgroupMessage = Added computer to workgroup '{0}'.
    CredentialsNotSpecifiedError = Must to specify credentials with domain.
    TestingComputerStateMessage = Testing computer state for '{0}'.
    CheckingComputerDescriptionMessage = Checking if computer description is '{0}'.
    CheckingDomainMemberMessage = Checking if the machine is a member of domain '{0}'.
    CheckingNotDomainMemberMessage = Checking if the machine is a not a member of a domain.
    CheckingWorkgroupMemberMessage = Checking if the machine is a member of workgroup '{0}'.
    DomainNameAndWorkgroupNameError = Only DomainName or WorkGroupName can be specified at once.
    ComputerNotInDomainMessage = This machine is not a domain member.
    DeletedExistingComputerObject = Deleted existing computer object with name '{0}' at path '{1}'.
    InvalidOptionPasswordPassUnsecuredJoin = Domain Join option 'PasswordPass' may not be specified if 'UnsecuredJoin' is specified.
    InvalidOptionCredentialUnsecuredJoinNullUsername = 'Credential' username must be null if 'UnsecuredJoin' is specified.
'@
