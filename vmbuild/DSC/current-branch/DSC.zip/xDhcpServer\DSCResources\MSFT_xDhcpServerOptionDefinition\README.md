# Description

The xDhcpServerOptionDefinition DSC resource manages DHCP option definitions.

## Requirements

- Target machine must be running Windows Server 2012 R2 or later.
- Target machine must be running at minimum Windows PowerShell 5.0.
